import pandas as pd
import openpyxl

   
def Get_Receiver_Port_Dict(filepath,sheetname):
    Receiver_Port_Dict_List = []
    df = pd.read_excel(filepath, sheet_name=sheetname)
    i = 0
    while i < len(df.values):
        Receiver_Port_Dict = {}
        Receiver_Port_Dict["SWC"] = df.values[i][0]
        Receiver_Port_Dict["Receiver_Port_List"] = [{"SWC":df.values[i][0], "Data_Type":df.values[i][2], "Data_Type_Property":df.values[i][3], "Receiver_Port":df.values[i][4],"Interface":df.values[i][5] , "Element":df.values[i][6], "Data_Access_Mode":df.values[i][7], "InitValue":df.values[i][9], "Sig_From":df.values[i][10], "Interface_Type":df.values[i][11], "Size":df.values[i][13]}]
        i = i + 1
        while i < len(df.values) and pd.notna(df.values[i][1]) and df.values[i][0] == df.values[i-1][0]:
            Receiver_Port_Dict["Receiver_Port_List"].append({"SWC":df.values[i][0], "Data_Type":df.values[i][2], "Data_Type_Property":df.values[i][3], "Receiver_Port":df.values[i][4],"Interface":df.values[i][5] , "Element":df.values[i][6], "Data_Access_Mode":df.values[i][7], "InitValue":df.values[i][9], "Sig_From":df.values[i][10], "Interface_Type":df.values[i][11], "Size":df.values[i][13]})
            i = i + 1
        Receiver_Port_Dict_List.append(Receiver_Port_Dict)
    return Receiver_Port_Dict_List


def Get_Sender_Port_Dict(filepath,sheetname):
    Sender_Port_Dict_List = []
    df = pd.read_excel(filepath, sheet_name=sheetname)
    i = 0
    while i < len(df.values):
        Sender_Port_Dict = {}
        Sender_Port_Dict["SWC"] = df.values[i][0]
        Sender_Port_Dict["Sender_Port_List"] = [{"SWC":df.values[i][0], "Data_Type":df.values[i][2], "Data_Type_Property":df.values[i][3], "Sender_Port":df.values[i][4],"Interface":df.values[i][5] , "Element":df.values[i][6], "Data_Access_Mode":df.values[i][7], "InitValue":df.values[i][9], "Sig_From":df.values[i][10], "Interface_Type":df.values[i][11], "Size":df.values[i][13]}]
        i = i + 1
        while i < len(df.values) and pd.notna(df.values[i][1]) and df.values[i][0] == df.values[i-1][0]:
            Sender_Port_Dict["Sender_Port_List"].append({"SWC":df.values[i][0], "Data_Type":df.values[i][2], "Data_Type_Property":df.values[i][3], "Sender_Port":df.values[i][4], "Interface":df.values[i][5] ,"Element":df.values[i][6], "Data_Access_Mode":df.values[i][7], "InitValue":df.values[i][9], "Sig_From":df.values[i][10], "Interface_Type":df.values[i][11], "Size":df.values[i][13]})
            i = i + 1
        Sender_Port_Dict_List.append(Sender_Port_Dict)
    return Sender_Port_Dict_List

