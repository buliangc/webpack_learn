先接收Rte_Read 后发送Rte_Write
# 1. 对 RTE层（接口,Port,连线）进行验证
    1. 检测Port是否创建在对应SWC上 规则: Rte_Write_SWC_Port_Element  Rte_Read_SWC_Port_Element
    （如果Rte.c包含Rte函数，则代表在SWC上添加了Data Access，表明该SWC含有该Port口）  未添加变量访问 或 未配置 或 配置与表格不符   ===》 输出未配置

# 2. 对 数据类型 进行验证  规则：满足以下格式     ===》 输出数据类型配置错误
    1.  指针 P2VAR(Perc9, AUTOMATIC, RTE_APPL_DATA) data
    2.  普通数据类型 OnOff1 data

# 3. 连线
    1. 内部连线 Internal/SUP  规则：返回值return RTE_STATUS
    2. 网络连线 Network  

    从网络上接收 Receive Port [不检测：唯一性]
    Rte_Read_AirDirecCtrlMgrREAL_CopilotSeatOccupySts_CopilotSeatOccupySts
    ```c
    FUNC(void, RTE_CODE) Rte_COMCbk_SGisAD4WinOpenReq_437R (void)
    {
        uint8 Rte_InternalBuffer;
        Rte_ComHookRx_SGisAD4WinOpenReq_437R();
        if (Rte_State == RTE_PARTITION_ACTIVE)
        {
            if (Com_ReceiveSignal(ComConf_ComSignal_SGisAD4WinOpenReq_437R, &Rte_InternalBuffer) == E_OK)
            {
                Rte_ComHook_SGisAD4WinOpenReq_437R_SigRx(&Rte_InternalBuffer);
                Rte_ReceiveBuffer__its_WinCtrlAtPass_AD4WinOpenReq_AD4WinOpenReq_value = Rte_InternalBuffer;
            }
        }
    }
    ```

    发送到网络上 Provide Port  [检测是否发送到网络,跨核：Rte_Smc_Rte_ComSendSignals_OsApplication_C0 非跨核：Com_SendSignal]
    ```c
    FUNC(Std_ReturnType, RTE_CODE) Rte_Write_PrkgClimaActvMgr_PrkgClimaHVReq_PrkgClimaHVReq (OnOff1 data)
    {
        Std_ReturnType Rte_Status = RTE_E_OK;
        Rte_WriteHook_PrkgClimaActvMgr_PrkgClimaHVReq_PrkgClimaHVReq_Start(data);
        if (Rte_State == RTE_PARTITION_ACTIVE)
        {
            Rte_Measure_itsPrkgClimaActvMgrREAL_PrkgClimaHVReq_PrkgClimaHVReq = data;
            Rte_ComHook_SGisPrkgClimaHVReq_310T_SigTx(&data);
            if (Com_SendSignal(ComConf_ComSignal_SGisPrkgClimaHVReq_310T, &data) != E_OK)
            {
                Rte_Status = RTE_E_COM_STOPPED;
            }
        }
        Rte_WriteHook_PrkgClimaActvMgr_PrkgClimaHVReq_PrkgClimaHVReq_Return(data);
        return Rte_Status;
    } /* FUNC(Std_ReturnType, RTE_CODE) Rte_Write_PrkgClimaActvMgr_PrkgClimaHVReq_PrkgClimaHVReq (OnOff1 data) */
    ```

# 4. IsUpdated 检测是否有IsUpdated函数
    ```c
    FUNC(boolean, RTE_CODE) Rte_IsUpdated_LoBeamSafe_VehSpdLgt_VehSpdLgt (void)
    {
        Rte_IsUpdatedHook_LoBeamSafe_VehSpdLgt_VehSpdLgt_Start();

        Rte_IsUpdatedHook_LoBeamSafe_VehSpdLgt_VehSpdLgt_Return();
        return FALSE;
    } /* FUNC(boolean, RTE_CODE) Rte_IsUpdated_LoBeamSafe_VehSpdLgt_VehSpdLgt (void) */
    ```

# 5. 初始值  没有连线就不会有初始值 [不检测：暂无需求]
    1.  Init
    2. 

# 6. 针对C/S口，只校验Client Port 生成Rte_Call函数是否正确

打包：pyinstaller -w --name Verify_RTE --add-data "./genshin.ico;./" --icon genshin.ico  --onefile gui.py