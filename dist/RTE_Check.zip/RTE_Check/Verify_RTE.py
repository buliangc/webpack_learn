# Author: 蔡宗阳
# Date: 2024.9.27
import re  
import pandas as pd  
import openpyxl  
from openpyxl.styles import Font  
import time  
import random  

# 用于填写备注
def fillInExcel(workbook, sheet_name, i, note):
    sheet = workbook[sheet_name]   
    # 颜色
    red_font = Font(color='FF0000')   
    green_font = Font(color='0000FF')   
    if sheet_name == "Client Port":
        cell = sheet.cell(row=i+2, column=8, value=note)  
    else:
        cell = sheet.cell(row=i+2, column=15, value=note)  

    if "完成" in note :
        cell.font = green_font 
    else:
        cell.font = red_font 
    
def find_text_between(start_patterns, end_patterns, content):  
    # 使用 OR (|) 运算符组合 start_patterns 和 end_patterns  
    start_pattern_combined = '|'.join([re.escape(pattern) for pattern in start_patterns])  
    end_pattern_combined = '|'.join([re.escape(pattern) for pattern in end_patterns])  

    # 创建正则表达式查找内容  
    pattern = re.compile(f'({start_pattern_combined})(.*?)(?=({end_pattern_combined}))', re.DOTALL)  
    # 查找所有匹配  
    match = pattern.search(content)  
    return match  

def check_rte_functions(workbook, file_path, function_name, data_type, sheet_name, i, content, Interface_Type):  
    # 定义模式  
    string = rf'FUNC(Std_ReturnType, RTE_CODE) {function_name} (P2VAR({data_type}, AUTOMATIC, RTE_APPL_DATA) data)'  
    string1 = rf'FUNC(Std_ReturnType, RTE_CODE) {function_name} (P2CONST({data_type}, AUTOMATIC, RTE_APPL_DATA) data)'  
    string2 = rf'FUNC(Std_ReturnType, RTE_CODE) {function_name} ({data_type} data)'  
    try:  
        function_body = find_text_between(    
            [string, string1, string2],    # 通配符模式  
            [string, string1, string2],     # 结束模式
            content  
        )  
       
        if function_body != None:
            connector_check(workbook, function_body.group(), Interface_Type, sheet_name, i)
        else:  
            fillInExcel(workbook, sheet_name,i, "未配置" ) 

    except FileNotFoundError:  
        print(f"文件未找到: {file_path}")  
    except Exception as e:  
        print(f"发生错误: {e}")  

# 数据类型检查
# def dataType_check(function_body, function_name, excel_path, sheet_name, i):

# 初始值检查
# def initValue_check(function_body, function_name, excel_path, sheet_name, i):

# 检查连线信息
def connector_check(workbook, function_body, Interface_Type, sheet_name, i):
    return_pattern = re.compile(r'\breturn\s+(\w+)\s*;')  
    # 搜索返回值的模式  
    return_match = return_pattern.search(function_body)  
    if return_match:  
        return_value = return_match.group(1)  
        if return_value == "Rte_Status": 
            if sheet_name == "Sender Port" and Interface_Type == "Network":
                if "Rte_Smc_Rte_ComSendSignals_OsApplication_C0" in function_body or "Rte_Smc_Rte_ComSendSignalGroups_OsApplication_C1_P0" in function_body or "Rte_Smc_Rte_ComSendSignals_OsApplication_C1_P0" in function_body or "Rte_Smc_Rte_ComSendSignals_OsApplication_0" in function_body or "Rte_Smc_Rte_ComSendSignalGroups_OsApplication_0" in function_body or "Com_SendSignal" in function_body:  
                    fillInExcel(workbook, sheet_name, i, "连线已完成" )   
                else:  
                    fillInExcel(workbook, sheet_name, i, "未连线，Com未配置或网络信号缺失" ) 
            else:
                fillInExcel(workbook, sheet_name, i, "连线已完成" ) 
        else:  
            fillInExcel(workbook, sheet_name, i, "未连线" )
    else:   
        fillInExcel(workbook, sheet_name, i, "函数返回值有问题" ) 

def process_ports(workbook, filePath, df, is_sender, sheet_name, content):  
    for i in range(len(df.values)):  
        SWC_Name = df.values[i][0]  
        Data_Access_Mode = df.values[i][7]  
        Data_Type = df.values[i][2]  
        Port = df.values[i][4]  
        Element = df.values[i][6]  
        Interface_Type = df.values[i][11]  
        
        function_name = f"Rte_Write_{SWC_Name}_{Port}_{Element}" if is_sender else f"Rte_Read_{SWC_Name}_{Port}_{Element}"  

        # 是否为IsUpdated  
        if Data_Access_Mode == "IsUpdated":  
            isupdateFunction_name = f"Rte_IsUpdated_{SWC_Name}_{Port}_{Element}"
            isUpdate_pattern = re.compile(  
                rf'FUNC\(boolean,\s*RTE_CODE\)\s*{isupdateFunction_name}\s*\(void\)\s*'  
            )  
            isUpdate_match = isUpdate_pattern.search(content)  
            if isUpdate_match:  
                fillInExcel(workbook, sheet_name, i, "ISupdate已完成" ) 
            else:
                fillInExcel(workbook, sheet_name, i, "ISupdate未配置" ) 
        else:  
            check_rte_functions(workbook, filePath, function_name, Data_Type, sheet_name, i, content, Interface_Type)  


def check_cs_functions(workbook, filePath, df, sheet_name, content):
    for i in range(len(df.values)):  
        SWC_Name = df.values[i][0]   
        Port = df.values[i][2]  
        Operation = df.values[i][4]  
        # SWC_Name = "ActSnrDCU"  
        # Port = "ActSnrDCU_algo_add_dtcRecord"
        # Operation = "algo_add_dtcRecord" 
        
        function_name = f"Rte_Call_{SWC_Name}_{Port}_{Operation}"
        
        string = rf'FUNC(Std_ReturnType, RTE_CODE) {function_name}'  
        function_body = find_text_between(    
            [string],    # 通配符模式  
            [string],     # 结束模式
            content  
        )  
        if function_body != None:
            return_pattern = re.compile(r'\breturn\s+(\w+)\s*;')  
            # 搜索返回值的模式  
            return_match = return_pattern.search(function_body.group())  
            if return_match:  
                return_value = return_match.group(1)  
                if return_value == "Rte_Status":
                    fillInExcel(workbook, sheet_name, i, "连线已完成" )   
                else:  
                    # print("未连线")
                    fillInExcel(workbook, sheet_name, i, "未连线" )
            else:   
                # print("函数返回值有问题")
                fillInExcel(workbook, sheet_name, i, "函数返回值有问题" )  
        else: 
            fillInExcel(workbook, sheet_name, i, "未配置" )  
            # print("没找到")

def has_client_port_sheet(workbook):  
    # 获取所有的工作表名称  
    sheet_names = workbook.sheetnames  
    
    # 检查是否存在 "Client Port" 工作表  
    return "Client Port" in sheet_names  

def has_sender_port_sheet(workbook):  
    # 获取所有的工作表名称  
    sheet_names = workbook.sheetnames  
    
    # 检查是否存在 "Sender Port" 工作表  
    return "Sender Port" in sheet_names  

def has_receiver_port_sheet(workbook):  
    # 获取所有的工作表名称  
    sheet_names = workbook.sheetnames  
    
    # 检查是否存在 "Receiver Port" 工作表  
    return "Receiver Port" in sheet_names  

def main(self, run_config):
    # excelPath = "./RTE_Check/驱动新增接口汇总ZCUD_23R3_U2_01_03.xlsx"  
    # filePath = './RTE_Check/Rte.c'  
    try:
        excelPath = run_config["excel_path"]
        filePath = run_config["file_path"]
        workbook = openpyxl.load_workbook(excelPath)  

        with open(filePath, 'r') as file:  
            content = file.read()  
        
        if has_receiver_port_sheet(workbook):
            # 读取 Excel 文件并处理 Receiver Port  
            df_receiver = pd.read_excel(excelPath, sheet_name="Receiver Port")  
            process_ports(workbook, filePath, df_receiver, False, "Receiver Port", content) 
            random_integer = random.randint(15, 35)  # 包含1和10  
            for i in range(random_integer):  
                time.sleep(0.01)  
                self.progress['value'] = i 
                self.label.config(text=f"进度: {i}%")  
        else:
            random_integer = random.randint(15, 35)  # 包含1和10  
            for i in range(random_integer):  
                time.sleep(0.01)  
                self.progress['value'] = i 
                self.label.config(text=f"进度: {i}%")  

        if has_sender_port_sheet(workbook):
            # 读取 Excel 文件并处理 Sender Port  
            df_sender = pd.read_excel(excelPath, sheet_name="Sender Port")  
            process_ports(workbook, filePath, df_sender, True, "Sender Port", content)
            for i in range(random_integer,100-random_integer-8):  
                time.sleep(0.01)  
                self.progress['value'] = i  
                self.label.config(text=f"进度: {i}%")  
        else:
            for i in range(random_integer,100-random_integer-8):  
                time.sleep(0.01)  
                self.progress['value'] = i  
                self.label.config(text=f"进度: {i}%")  
                
        # 如果存在client port页面
        if has_client_port_sheet(workbook):
            # 读取 Excel 文件并处理 Client Port   Rte_Call
            df_client = pd.read_excel(excelPath, sheet_name="Client Port") 
            check_cs_functions(workbook, filePath, df_client, "Client Port", content) 

        workbook.save(excelPath)
        for i in range(100-random_integer-8, 101):  
            time.sleep(0.01)    
            self.progress['value'] = i  
            self.label.config(text=f"进度: {i}%")  
        self.start_button.config(state="normal")  
        self.label.config(text="任务完成🎉🎉🎉！")  
    except PermissionError:  
        self.showPermissionErrorMessage()
    except Exception as e:  
        self.showErrorMessage(e)

    print("结束")
