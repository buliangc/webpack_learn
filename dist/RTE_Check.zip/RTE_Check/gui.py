# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
# from gitandcopy import run
import configparser
from tkinter import messagebox
import os
import sys  
from bs4 import BeautifulSoup
import threading  
import Verify_RTE
import subprocess  

global count
# 创建控件的封装
class CreatWidget(object):
    # 文件夹选择并将名字插入到entry中
    def select_folder(self,entry):
        folder_path = filedialog.askdirectory()
        entry.delete(0, tk.END)
        entry.insert(0, folder_path)
    # 文件选择并将名字插入到entry中
    def select_file(self,entry):
        file_path = filedialog.askopenfilename()
        print("select_file: ",file_path)
        entry.delete(0, tk.END)
        entry.insert(0, file_path)
    def open_file_location(self,path):  
        file_path = path.get()
        if os.path.exists(file_path):  
            os.startfile(file_path)
        else:  
            messagebox.showerror("错误", "文件不存在")  
    def open_path_location(self,path):  
        file_path = path.get()
        directory_path = os.path.dirname(file_path) 
        if os.path.exists(directory_path):  
            os.startfile(directory_path)
        else:  
            messagebox.showerror("错误", "路径不存在")  
    # 创建文本
    def create_label(self,window, text, x, y):
        label = tk.Label(window, fg="black", bg="white", text=text)
        label.place(x=x, y=y)
        return label
    # 创建输入框
    def create_entry(self,window, text, width, x, y):
        entry = tk.Entry(window, width=width)
        entry.insert(0, text)
        entry.place(x=x, y=y)
        return entry
    # 创建按钮并绑定函数
    def create_button(self,window, text, command, x, y,width, bg, fg):
        button = tk.Button(window, fg = fg, bg = bg, command=command, text=text, width=width, height=1)
        button.place(x=x, y=y)
        return button
    # 设置选择框的值
    def set_combobox_value(self,combobox, value):
        if value in combobox['values']:
            index = combobox['values'].index(value)
            combobox.current(index)
    # 创建选择框，配置可选配置及初始值
    def create_combobox(self,window, values, current, x, y,width=40):
        combobox = ttk.Combobox(window, width=width, textvariable=tk.StringVar(), state="readonly")
        combobox['values'] = values
        combobox.place(x=x, y=y)
        self.set_combobox_value(combobox,current)
        return combobox

class ConfigurationGUI(CreatWidget): 
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Verify_RTE  (By ElioCai)")
        # print(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'genshin.ico'))
        self.window.iconbitmap(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'genshin.ico')) 
        self.center_window() 
        self.window.geometry('620x320')
        self.window.configure(background="#f0f0f0")
        
        self.create_widgets()
        
    def center_window(self):  
        screen_width = self.window.winfo_screenwidth()  
        screen_height = self.window.winfo_screenheight()  
        window_width = 620  
        window_height = 320  
        x = (screen_width // 2) - (window_width // 2)  
        y = (screen_height // 2) - (window_height // 2)  
        self.window.geometry(f"{window_width}x{window_height}+{x}+{y}") 

    def create_widgets(self):
        # 初始化配置
        self.load_config()
        # Path = self.config.sections()

        # 配置项组件
        self.configframe = tk.Frame(self.window, width=590, height=290, bg='lightgray') 
        self.configframe.place(x=15,y=15,anchor="nw")
        # =========================接口仓库 y = 50=======================
        # 接口表路径
        self.label_excel_path = self.create_label(self.window, "选择接口表文件:", 50, 50)
        self.entry_excel_path = self.create_entry(self.window, self.excel_path, 40, 180, 50)
        self.button_excel_path = self.create_button(self.window, "选择", lambda: self.select_file(self.entry_excel_path), 490, 50,4,bg="#0078d7", fg="white")
        self.button_open_path = self.create_button(self.window, "打开", lambda: self.open_file_location(self.entry_excel_path), 550, 50,4,bg="#DAA520", fg="white")

        # =========================工程仓库 y = 100=======================
        # 工程仓库路径
        self.label_file_path = self.create_label(self.window, "选择RTE文件:", 50, 100)
        self.entry_file_path = self.create_entry(self.window, self.file_path, 40, 180, 100)
        self.button_file_path = self.create_button(self.window, "选择", lambda: self.select_file(self.entry_file_path), 490, 100,4, bg="#0078d7", fg="white")
        self.button_open_path = self.create_button(self.window, "打开", lambda: self.open_path_location(self.entry_file_path), 550, 100,4,bg="#DAA520", fg="white")

        # 选择ZCU类型
        self.label_ZCU = self.create_label(self.window, "选择ZCU类型:", 50, 150)
        self.select_ZCU = self.create_combobox(self.window, ["ZCUD", "ZCUP"], self.ZCU_type, 180, 150, 37)

        # 创建进度条  
        self.progress = ttk.Progressbar(self.window, orient="horizontal", length=300, mode="determinate")  
        self.progress.place(x=50, y=200)  # 在窗体的指定位置放置进度条  

        # 创建按钮以启动任务  
        self.start_button = tk.Button(self.window, text="原神启动", command=self.start_task)  
        self.start_button.place(x=250, y=250)  # 在窗体的指定位置放置进度条  

        # 创建标签显示进度信息  
        self.label = self.create_label(self.window, "完成进度: 0%", 50, 400)
        self.label.place(x=380, y=200)  # 在窗体的指定位置放置进度条  

        # 保存配置项按钮
        self.button_config = self.create_button(self.window, "保存配置页", lambda: self.save_config(False), 490, 150,10,bg="#28a745", fg="white")

        # 退出保存配置
        self.window.protocol("WM_DELETE_WINDOW", lambda: self.save_config(True))
        
    def start_task(self):  
        # 禁用按钮以防止多次点击  
        self.start_button.config(state="disabled")  
        self.progress['value'] = 0  
        self.label.config(text="进度: 0%")  
        
        # 创建一个线程来处理任务，避免阻塞主线程  
        threading.Thread(target=self.button_click).start()  

    def load_config(self):
        self.config = configparser.ConfigParser()
        self.config_file = 'config.ini' 
        if os.path.exists(self.config_file):
            self.config.read(self.config_file, encoding='UTF-8')
            self.excel_path = self.config.get('Path', 'excel_path', fallback='')
            self.file_path = self.config.get('Path', 'file_path', fallback='')
            self.ZCU_type = self.config.get('Path', 'ZCU_type', fallback='')
        else:
            config_file_path = os.path.join(os.path.dirname(os.path.realpath(sys.executable)), self.config_file) 
            # config_file_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), self.config_file)  
            print(config_file_path)
            if not os.path.exists(config_file_path):
                with open(config_file_path,'w', encoding='utf-8') as f:
                    f.close()
            self.config.read(config_file_path,encoding='UTF-8')
            self.excel_path = ""
            self.file_path = ""
            self.ZCU_type = ""
    # 保存当前配置到配置文件
    def save_config(self,close):
        self.config['Path'] = {  
            'excel_path': self.entry_excel_path.get(),  
            'file_path': self.entry_file_path.get(),  
            'ZCU_type': self.select_ZCU.get()
        } 
        # current_folder = os.path.dirname(os.path.realpath(__file__))
        # print(current_folder,os.getcwd())
        with open(self.config_file, 'w', encoding='utf-8') as configfile:
            self.config.write(configfile)
        if(close):
            self.window.destroy()

    # 启动按钮
    def button_click(self):
        print("按钮被点击了！")
        run_config = {}
        run_config["excel_path"] = self.entry_excel_path.get()
        run_config["file_path"] = self.entry_file_path.get()
        run_config["ZCU_type"] = self.select_ZCU.get()
        # self.run_task(run_config)
        Verify_RTE.main(self, run_config)

    def showPermissionErrorMessage(self):
        messagebox.showerror("错误", "无法访问 Excel 文件。该文件可能正在被打开，请关闭文件再试。")

    def showErrorMessage(self, e):
        messagebox.showerror("错误", f"发生错误: {str(e)}")  

    def start(self):
        self.window.mainloop()

if __name__ == "__main__":
    config_gui = ConfigurationGUI()
    config_gui.start()
