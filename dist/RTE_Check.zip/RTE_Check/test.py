import re  
import pandas as pd  
import openpyxl  
from openpyxl.styles import Font    # 导入样式类 

filePath = './RTE_Check/Rte.c'  
excelPath = "./RTE_Check/驱动接口汇总ZCUP_Copy.xlsx"  
function_name = "Rte_Write_FuelLvlSenrIf_pFuSnsrActvSide_FuSnsrActvSide"
data_type = "FuLvlSnsrRawValWithQly"


with open(filePath, 'r') as file:  
    content = file.read()  


def find_text_between(file_path, start_patterns, end_patterns):  
    
    # 使用 OR (|) 运算符组合 start_patterns 和 end_patterns  
    start_pattern_combined = '|'.join([re.escape(pattern) for pattern in start_patterns])  
    end_pattern_combined = '|'.join([re.escape(pattern) for pattern in end_patterns])  

    # 创建正则表达式查找内容  
    pattern = re.compile(f'({start_pattern_combined})(.*?)(?=({end_pattern_combined}))', re.DOTALL)  
    
    # 查找所有匹配  
    match = pattern.search(content)  
    
    # 处理匹配结果，返回需要的部分  
    return match  # match[1] 是我们想要的内容  


# 定义模式  
string = rf'FUNC(Std_ReturnType, RTE_CODE) {function_name} (P2VAR({data_type}, AUTOMATIC, RTE_APPL_DATA) data)'  
string1 = rf'FUNC(Std_ReturnType, RTE_CODE) {function_name} (P2CONST({data_type}, AUTOMATIC, RTE_APPL_DATA) data)'  
string2 = rf'FUNC(Std_ReturnType, RTE_CODE) {function_name} ({data_type} data)'  

# 调用函数，搜索两个模式  
results = find_text_between(  
    filePath,   
    [string, string1, string2],    # 通配符模式  
    [string, string1, string2]     # 结束模式  
)  
# 输出结果  
# for result in results:  
print(results.group())
code_segment = results.group()
if "Com_SendSignal" in code_segment:  
    print("函数中包含 'Com_SendSignal'")  
else:  
    print("函数中不包含 'Com_SendSignal'")  